import 'package:astro_tak/models/astrologer_data_model.dart';
import 'package:astro_tak/services/astrologer_data_service.dart';
import 'package:astro_tak/utilities/loading_enum.dart';
import 'package:flutter/material.dart';

class AstrologerDataProvider with ChangeNotifier {
  LoadingStatus loadingStatus = LoadingStatus.searching;
  AstrologerDataModel? astrologerDataModel;

  void fetchAstrologerData() async {
    this.loadingStatus = LoadingStatus.searching;
    try {
      astrologerDataModel =
      await AstrologerDataServices().fetchAstrologerDataService();
      this.loadingStatus = LoadingStatus.completed;
      print("questions length ${astrologerDataModel?.astrologerData!.length}");
    } catch (error) {
      this.loadingStatus = LoadingStatus.empty;
      print('error in fetchQuestionsData $error');
    }
    print("in fetchQuestionsData $loadingStatus");
    notifyListeners();
  }
}
