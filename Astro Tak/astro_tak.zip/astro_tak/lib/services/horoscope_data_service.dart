
import 'dart:convert';

import 'package:astro_tak/utilities/network_helper.dart';

class HomeDataServices {
  NetworkHelper _networkHelper = NetworkHelper();

  // Future<HomeDataModel> fetchHomeDataService() async {
  //   Response response = await _dioNetworkHelper.getDataAuthHeader(
  //       ApiEndpoints.homeDataApi, ApiEndpoints.tempApiJwt);
  //   print("Response is $response");
  //   final homeDataModel = homeDataModelFromJson(json.encode(response.data));
  //   return homeDataModel;
  // }
}
