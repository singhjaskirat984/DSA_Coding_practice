import 'package:astro_tak/components/descriptions.dart';
import "package:flutter/material.dart";

class circle extends StatelessWidget {
  final String image;
  final String txt;
  final String desText;

  const circle({Key? key, required this.image, required this.txt,required this.desText})
      : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(10.0),
      child: Column(
        children: [
          Container(
              width: 80,
              height: 80,
              decoration: new BoxDecoration(
                color: Colors.blue[50],
                shape: BoxShape.circle,
              ),
              child: Tab(
                icon: Container(
                  child: Image(
                    image: AssetImage(
                      image,
                    ),
                    fit: BoxFit.cover,
                  ),
                  height: 50,
                  width: 50,
                ),
              )
          ),
          SizedBox(height: 5.0,),
          Text(txt,style: TextStyle(fontWeight: FontWeight.bold,fontFamily: "Roboto"),),
          SizedBox(height: 5.0,),
          descriptions(text: desText, size: 12.0, color: Colors.grey)
        ],
      ),
    );
  }
}
