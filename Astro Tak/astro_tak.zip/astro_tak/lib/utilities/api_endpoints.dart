class ApiEndpoints {
  static String kApiBaseUrl = 'https://astro-tak-api.herokuapp.com/';
  static String questionDataApi = 'questions';
  static String astrologerDataApi = 'astrologer';
  static String homeDataApi = '';
  static String reportDataApi = '';
}
