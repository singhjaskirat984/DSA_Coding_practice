enum LoadingStatus {
  completed,
  searching,
  empty,
}
