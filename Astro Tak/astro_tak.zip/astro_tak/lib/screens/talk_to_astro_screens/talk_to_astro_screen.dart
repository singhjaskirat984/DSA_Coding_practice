import 'package:astro_tak/utilities/colored_safe_area.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class TalkToAstroScreen extends StatefulWidget {
  static const String id = 'talk_to_astro_screen';

  const TalkToAstroScreen({Key? key}) : super(key: key);

  @override
  _TalkToAstroScreenState createState() => _TalkToAstroScreenState();
}

class _TalkToAstroScreenState extends State<TalkToAstroScreen> {
  @override
  Widget build(BuildContext context) {
    return ColoredSafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: Text('TalkToAstroScreen'),
        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              Text('TalkToAstroScreen Screen'),
            ],
          ),
        ),
      ),
    );
  }
}
