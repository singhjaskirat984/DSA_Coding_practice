//    final homeDataProvider = Provider.of<HomeDataProvider>(context);
// homeDataProvider.loadingStatus ==
//                           LoadingStatus.completed


import 'package:astro_tak/utilities/colored_safe_area.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class AskQuestionScreen extends StatefulWidget {
  static const String id = 'ask_question_screen';

  const AskQuestionScreen({Key? key}) : super(key: key);

  @override
  _AskQuestionScreenState createState() => _AskQuestionScreenState();
}

class _AskQuestionScreenState extends State<AskQuestionScreen> {



  @override
  Widget build(BuildContext context) {
    return ColoredSafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: Text('AskQuestionScreen'),
        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              Text('AskQuestionScreen Screen'),
            ],
          ),
        ),
      ),
    );
  }
}
