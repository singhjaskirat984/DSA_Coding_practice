import 'package:astro_tak/utilities/colored_safe_area.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ReportScreen extends StatefulWidget {
  static const String id = 'report_screen';

  const ReportScreen({Key? key}) : super(key: key);

  @override
  _ReportScreenState createState() => _ReportScreenState();
}

class _ReportScreenState extends State<ReportScreen> {
  @override
  Widget build(BuildContext context) {
    return ColoredSafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: Text('ReportScreen'),
        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              Text('ReportScreen Screen'),
            ],
          ),
        ),
      ),
    );
  }
}
