package com.astroTak.com.astro_tak

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
