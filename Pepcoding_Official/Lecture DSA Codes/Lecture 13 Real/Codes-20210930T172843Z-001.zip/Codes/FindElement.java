import java.io.*;
import java.util.*;

public class Main {

  public static void main(String[] args) throws Exception {
    // write your code here
    Scanner scn = new Scanner(System.in);
    
    int n = scn.nextInt();
    int[] arr = new int[n];
    for(int i = 0; i < arr.length; i++){
        arr[i] = scn.nextInt();
    }

    int data = scn.nextInt();

    int foundAt = -1;
    for(int i = 0; i < arr.length; i++){
        if(arr[i] == data){
            foundAt = i;
            break;
        }
    }

    System.out.println(foundAt);
  }

}